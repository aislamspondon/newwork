import "antd/dist/antd.css";
import "./App.css";
import LoginRoute from "./LoginRoute";

function App() {
  return (
    <div className="App">
      <LoginRoute />
      {/* <LayoutDashboard /> */}
    </div>
  );
}

export default App;
