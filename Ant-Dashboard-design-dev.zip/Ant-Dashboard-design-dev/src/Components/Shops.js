import React from "react";
import ApprovePendingShop from "./ApprovePendingShop";
import FindShop from "./FindShop";
export default function Shops() {
  return (
    <>
      <ApprovePendingShop />
      <FindShop />
    </>
  );
}
